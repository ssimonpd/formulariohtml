<?php 


	define('DB_HOST', '192.168.100.234');
	define('DB_USER', 'etecia');
	define('DB_PASS', '123456');
	define('DB_NAME', 'android');